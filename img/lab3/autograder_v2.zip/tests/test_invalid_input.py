import unittest
from gradescope_utils.autograder_utils.decorators import weight, visibility, number
from gradescope_utils.autograder_utils.files import check_submitted_files
import glob
import inspect
import importlib
import ast

import grading_util
from grading_util import insensitive_glob
import project2_conversion
import sys
import io
from contextlib import redirect_stdout


class TestErrorHandling(unittest.TestCase):
    @weight(1)
    @number("1.3")
    @visibility("visible")
    def test_for_errors(self):
        """Check Invalid Input is correctly handled"""
        project2_conversion.input = lambda _: '-1'
        f = io.StringIO()
        with redirect_stdout(f):
            project2_conversion.metersToFeet()
        output = f.getvalue().strip()
        print(output)
        project2_conversion.input = input

        self.assertEqual(output.strip(), 'Invalid Input', "Invalid input not handled correctly")
