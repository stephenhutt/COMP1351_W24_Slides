import unittest
from gradescope_utils.autograder_utils.decorators import weight, visibility, number
from gradescope_utils.autograder_utils.files import check_submitted_files
import glob
import inspect
import importlib
import ast

import grading_util
from grading_util import insensitive_glob
import project2_conversion
import sys
import random
import io
from contextlib import redirect_stdout


def getResponses():
    inputValue = round(random.random() * 3, 2)
    project2_conversion.input = lambda _: '{0}'.format(inputValue)
    f = io.StringIO()
    with redirect_stdout(f):
        project2_conversion.metersToFeet()
    output = f.getvalue().strip()
    #print(output)
    answerFt, answerIn, AnswerResp = grading_util.height_to_feet_inches(inputValue)
    studentMet, studentFt, studentIn = grading_util.processP2String(output)
    project2_conversion.input = input
    return studentMet, studentFt, studentIn, output, answerFt, answerIn, AnswerResp, inputValue

class TestValues(unittest.TestCase):
    @weight(2)
    @number("1.5")
    @visibility("visible")
    def test_feet(self):
        """Check Feet Conversion is correct"""
        numtests = 4
        for i in range(numtests):
            sM, sF, sI, sR, aF, aI, aR, aM = getResponses()
            self.assertEqual(sF, aF, "Feet Conversion Error")
        print("All Feet Values correctly calculated")

    @weight(2)
    @number("1.6")
    @visibility("visible")
    def test_inches(self):
        """Check Inches Conversion is correct"""
        numtests = 4
        for i in range(numtests):
            sM, sF, sI, sR, aF, aI, aR, aM = getResponses()
            self.assertEqual(sI, aI, "Inches Conversion Error")
        print("All Inches Values correctly calculated")

    @weight(2)
    @number("1.7")
    @visibility("visible")
    def test_ResponseString(self):
        """Check formatted output is correct"""
        numtests = 4
        for i in range(numtests):
            sM, sF, sI, sR, aF, aI, aR, aM  = getResponses()
            self.assertEqual(sR, aR, "Strings incorrectly formatted (note issue may also be in inches or feet conversion, fix those errors first)")
        print("All output correctly formatted")

    @weight(1)
    @number("1.8")
    @visibility("visible")
    def test_Input_Conversion(self):
        """Check Program handles valid input correctly"""
        numtests = 2
        for i in range(numtests):
            sM, sF, sI, sR, aF, aI, aR, aM  = getResponses()
            self.assertEqual(sM, aM, "Input provided in print statement does not match input provided by user - double check this")
        print("Valid Input correctly processed")

if __name__ == '__main__':
    getResponses()