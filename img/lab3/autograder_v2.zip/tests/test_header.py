import unittest
from gradescope_utils.autograder_utils.decorators import weight, visibility, number
from gradescope_utils.autograder_utils.files import check_submitted_files
import glob

from grading_util import insensitive_glob


headerCode = ["File Name:","Author:","Date:","Course:","Assignment:"]

class TestHeaderComments(unittest.TestCase):
    @weight(0.5)
    @number("1.1")
    @visibility("visible")
    def test_header(self):
        """Check Header Components"""
        files = insensitive_glob("project2_conversion.py")
        file1 = open(files[0], 'r')
        Lines = file1.read()
        count = 0
        for element in headerCode:
            if element.lower().strip() in Lines.lower():
                count += 1
        self.assertEqual(count, 5, 'File Header is missing some required information')
        print('File Header has all required information!')

    @weight(0.5)
    @number("1.2")
    @visibility("visible")
    def test_comments(self):
        """Check Comments in File"""
        files = insensitive_glob("project2_conversion.py")
        file1 = open(files[0], 'r')
        lines = file1.readlines()
        count = 0
        for l in lines:
            if l.strip().startswith("#"):
                count += 1
        self.assertGreaterEqual(count, 2, 'Less than 2 comments in file')
        print('File has comments - note that usefulness of comments is tested manually ')