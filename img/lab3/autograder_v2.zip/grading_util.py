import glob
import sys
from io import StringIO
from contextlib import redirect_stdout

def insensitive_glob(pattern):
    def either(c):
        return '[%s%s]' % (c.lower(), c.upper()) if c.isalpha() else c
    return glob.glob(''.join(map(either, pattern)))

def processP2String(string):
    elements = string.strip().split()
    met = float(elements[3])
    ft = int(elements[6])
    inches = float(elements[9])

    return met, ft, inches


def height_to_feet_inches(height_m):
    # Constants for conversion
    meters_to_feet = 3.28084
    feet_in_a_foot = 12

    # Convert meters to total feet
    total_feet = height_m * meters_to_feet

    # Split into feet and inches
    feet = int(total_feet)
    inches = (total_feet - feet) * feet_in_a_foot
    response_str = "A height of {0} meters is {1} feet and {2} inches.".format(height_m, feet, round(inches, 2))
    return feet, round(inches, 2), response_str

class Capturing(list):
    def __enter__(self):
        self._stdout = sys.stdout
        sys.stdout = self._stringio = StringIO()
        return self
    def __exit__(self, *args):
        self.extend(self._stringio.getvalue().splitlines())
        del self._stringio    # free up some memory
        sys.stdout = self._stdout
